<?php

namespace App\Http\Controllers\Content;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Session;
use Illuminate\Routing\UrlGenerator;
 
class ContentController extends Controller
{
    /**
     * page label slug
     */
    public $page = 'content';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(Request $request)
    {
        $this->request = $request;
    }

    /**
     * Create a SESSION user controller load.
     *
     * @return boolean(true/false)
     */
    public function user_exits () 
    {
        return $this->request->session()->has('user') AND $this->request->session()->exists('user') ? true : false;
    }

    /**
     * Create a new controller load.
     *
     * @return objects
     */
    public function load ($id=null) 
    {
        $data = $this->request->session()->all();
        $returns = [
            'page'=>$this->page,
            'session'=>$data
        ];
        return $returns;
    }

    /**
     * Create a view controller load.
     *
     * @return void
     */
    public function view ($page=null) 
    {
        return view($page,$this->load());
    }

    /**
     * Create a view-template controller load.
     *
     * @return void
     */
    public function template ($page=null) 
    {
        $html  = null;
        $html .= $this->view('themes/blank/layouts/header');
        $html .= $this->view($page); 
        $html .= $this->view('themes/blank/layouts/footer');
        return $html;
    }

    /**
     * Show the application dashboard.
     * 
     * @return \Illuminate\Http\Response
     */
    public function index ()
    {
        $params = $this->load();
        return $this->template('themes/blank/index');
    }
}
