<!-- html - START -->
<html lang="<?php echo app()->getLocale(); ?>">
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- CSRF Token -->
<meta name="csrf-token" content="<?php echo csrf_token(); ?>">
<title>
    Home > <?php echo config('app.name'); ?>    
</title>
<!-- Fonts -->
<link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
<!-- Styles -->
<link href="<?php echo asset('css/app.css'); ?>" rel="stylesheet" id="app" />
<link href="<?php echo asset('css/styles.css'); ?>" rel="stylesheet" id="styles" />
<!-- html - END -->

<div class="lp-themes--header">
    <div class="lp-themes--header-column1">
        <?php
            echo config('app.name');
        ?>
    </div>
    <div class="lp-themes--header-column2">
        Menu
    </div>
</div>