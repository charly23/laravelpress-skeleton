<div class="lp-themes--footer">
    Footer
</div>