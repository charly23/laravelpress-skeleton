<div class="lp-admin--register">
    Register
</div>