<div class="lp-admin--footer">
    Footer
</div>