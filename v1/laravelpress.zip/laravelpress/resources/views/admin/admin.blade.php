<div class="lp-admin--panel">
    Dashboard
</div>


