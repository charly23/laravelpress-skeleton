<div class="lp-admin--panel">
    <?php
        echo view('admin/interface/login');
    ?>
</div>


